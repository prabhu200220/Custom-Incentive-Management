<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "employee_notification_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve notifications
$sql = "SELECT * FROM notifications";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    echo "<h1>Notifications</h1>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Sender Name</th><th>Recipient Email</th><th>Message</th><th>Status</th><th>Created At</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["sender_name"] . "</td>";
        echo "<td>" . $row["recipient_email"] . "</td>";
        echo "<td>" . $row["message"] . "</td>";
        echo "<td>" . $row["status"] . "</td>";
        echo "<td>" . $row["created_at"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No notifications found.";
}

// Close connection
$conn->close();
?>
