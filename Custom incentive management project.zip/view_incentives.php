<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "incentives_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM incentives";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Sales: " . $row["sales"] . " - Target: " . $row["target"] . " - Incentive: " . $row["incentive"] . " - Bonus: " . $row["bonus"] . " - Holiday: " . ($row["holiday"] ? 'Yes' : 'No') . " - Total Incentive: " . $row["total_incentive"] . "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>
