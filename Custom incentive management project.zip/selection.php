<?php
// Database connection parameters
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$database = "holiday_packages_db"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve all packages
$sql = "SELECT * FROM holiday_packages";
$result = $conn->query($sql);

// Display packages
if ($result->num_rows > 0) {
    echo "<h2>All Holiday Packages:</h2>";
    echo "<table border='1'>";
    echo "<tr><th>Package Name</th><th>Destination</th><th>Activities</th><th>Duration</th><th>Accommodation</th><th>Price</th><th>Travel Dates</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["package_name"] . "</td>";
        echo "<td>" . $row["destination"] . "</td>";
        echo "<td>" . $row["activities"] . "</td>";
        echo "<td>" . $row["duration"] . " days</td>";
        echo "<td>" . $row["accommodation"] . "</td>";
        echo "<td>$" . $row["price"] . "</td>";
        echo "<td>" . $row["travel_dates"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No packages found.";
}

// Close connection
$conn->close();
?>
