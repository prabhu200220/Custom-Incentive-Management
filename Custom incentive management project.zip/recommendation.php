<?php
// Step 1: Create the database and table
$servername = "localhost";
$username = "root";
$password = "";
$database = "holiday_packages_db";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql_create_db = "CREATE DATABASE IF NOT EXISTS $database";
if ($conn->query($sql_create_db) === TRUE) {
    header("Location: selection.php");
   
} else {
    echo "Error creating database: " . $conn->error;
}

// Switch to the newly created database
$conn->select_db($database);

// Create table to store holiday packages
$sql_create_table = "CREATE TABLE IF NOT EXISTS holiday_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(100) NOT NULL,
    destination VARCHAR(50) NOT NULL,
    activities VARCHAR(255) NOT NULL,
    duration INT NOT NULL,
    accommodation VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    travel_dates DATE NOT NULL
)";
if ($conn->query($sql_create_table) === TRUE) {
    "header (Location: selection.php)";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
