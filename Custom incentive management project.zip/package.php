<?php
// Connect to MySQL
$conn = mysqli_connect("localhost", "root", "", "holiday_packages");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get form data
$name = $_POST['name'];
$description = $_POST['description'];
$price = $_POST['price'];

// Insert data into packages table
$sql = "INSERT INTO packages (name, description, price) VALUES ('$name', '$description', '$price')";

if (mysqli_query($conn, $sql)) {
    header("Location: show.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);
?>
