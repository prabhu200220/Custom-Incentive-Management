<?php
// Establish database connection
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP
$dbname = "registration";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = $_POST["FullName"];
    $email = $_POST["Email"];
    $password = $_POST["Password"];
    $userType = $_POST["UserType"];

    $sql = "INSERT INTO users (FullName, Email, Password, UserType)
            VALUES ('$fullName', '$email', '$password', '$userType')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
       
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
