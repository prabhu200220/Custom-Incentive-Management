<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: rgb(45, 230, 55);
            color: rgb(220, 250, 215);
            font-size: 14px;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            margin: 0px;
        }

        #container {
            width: auto;
            height: auto;
            background: white;
            margin: auto;
        }

        #header {
            background: black;
            height: 50px;
          
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            display: flex;
            color: rgb(224, 239, 12);
       align-items: center;
             font-size: 30px;
             font-family: 'Times New Roman', Times, serif;
        }
        
        #header .p{
            text-align: center;
            text-emphasis-position: ;
        }
        
        #header .logo {
            max-height: 100%;
            /* Ensure the logo doesn't exceed the height of the header */
        }

        #header .social-icons {
            font-size: 30px;
            color: white;
        }

        #header .social-icons a {
            margin-right: 10px;
            text-decoration:none;
            color: white;
        }

        #header .social-icons a:last-child {
            margin-right: 0; /* Remove margin for the last child, i.e., Facebook icon */
        }

        #banner {
            background-color:rgb(72, 0, 255) ;
            width:auto;
            height: 150px;
            overflow: hidden;
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            display: flex;
        }
        #left-column, #right-column {
            width: 50%;
            height: 300px;
            overflow: hidden;
            background-color:white;
            text-align: center;
            padding: 20px;
            background-size: cover;
           
        }

        #right-column {
            background-color: white; 
            color:green;
        }
        #left-column img {
            max-width: 100%; /* Make sure the image doesn't exceed the width of its container */
            height: auto;
            background-position: center;
            background-size: cover;
        }
       
        #menu {
            background: rgb(40, 102, 121);
            height: 50px;
        }

        #menu .main-menu {
            margin: 0px;
            padding: 0px;
            list-style: none;
        }

        #menu .main-menu li {
            float: left;
            margin-right:10px;
        }

        #menu .main-menu li a {
            text-decoration: none;
            background: white;
            color: rgb(149, 48, 110);
            padding: 16px 16px;
            display: block;
        }

        #menu .main-menu li a:hover {
            background: blanchedalmond;
        }

        #menu .main-menu .dropdown {
            position: relative;
        }

        #menu .main-menu .dropdown ul {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            padding: 10px;
        }

        #menu .main-menu .dropdown:hover ul {
            display: block;
        }

        #body {
            background-image: url(HYS.JPEG);
            overflow: hidden;
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            width: 1500px;
             height: 700px;
    
        }

        #footer {
            background: burlywood;
            height: 55px;
            overflow: hidden;
            text-align: center; 
            padding-top: 15px; 
            font-size: 30px; 
           font-family: 'Arial', sans-serif;
        }
        
        #footer .marquee {
            animation: marquee 10s linear infinite;
        }

        @keyframes marquee {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }
        #create{
            background-color:white ;
            width:auto;
            height: 300px;
            overflow: hidden;
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover; 
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        #container1, #container2, #container3 {
            background-color: black;
            width: 30%; 
            height: 300px;
            overflow: hidden;
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            text-align: center;
            
        }

        #container2 {
            background-color:rgb(238, 25, 25);
        }

        #container3 {
            background-color: rgb(224, 34, 34);
        }
    </style>
</head>
<body>
    <div id="container">
        <div id="header">
            <p>HYSCALER</p>
           <div class="social-icons">
                <!-- Facebook Icon -->
                <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
                <!-- Twitter Icon -->
                <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
            </div> 
        </div>
        <div id="banner">
            <div id="left-column">
                <img src="HY.jpeg" alt="Left Column Image">
            </div>
            <div id="right-column">
                <ul class="header-phone-email">
                    <li><a href="login.html" target="_blank" style="font-size: 15px;color: #ef0a18;font-weight: 700;"> Login</a>  </li>
                    <li><i class="fa fa-phone"></i> 7328037446</li>
                    <li><i class="fa fa-envelope"></i>prabhuhyscale.ac.in</li>
                </ul>
            </div>

        </div>
        <div id="menu">
            <ul class="main-menu">
                <li class="dropdown">
                    <a href="#">Home</a>
                    <ul>
                        
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#">Contact Us</a>
                    <ul>
                        <li><a href="view_notifications.php">Admin</a></li>
                      
                       
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#">Package Details</a>
                    <ul>
                        <li><a href="package.html">package</a></li>
                        <li><a href="#"></a></li>
                        <li><a href="#">Management Service </a></li>
                        
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#">Our Services</a>
                    <ul>
                        <li><a href="#">Carrier</a></li>
                        <li><a href="#">Best In Hostel</a></li>
                        <li><a href="#">Best Maintenance</a></li>
                        <li><a href="#">Our Facilities</a></li>
                    </ul>
                </li>
                
                </li>
            </ul>
        </div>
        <div id="body">
           <p>a</p>
        </div>
        <div id="footer">
            <div class="marquee">Your scrolling text goes here. Repeat it for as long as needed.</div>
        </div>
        <div id="create">
            <div id="container1">
                <p>MISSION</p>
                <p>vcxghvxccgddhdgdgfhhhh
                    dgvcvgdsvcgvcgcvsvcvvcg
                    vcgvgcvvvvvvvvvvvvcvvcvfgcgc
                    sdgjsgbchjdgschjdsgchgds
                    hgsavhgvhsdcc
                </p>
                
            </div>
            <div id="container2">
                <p>vission</p>
            </div>
            <div id="container3"></div>
        </div>
    </div>
</body>
</html>
