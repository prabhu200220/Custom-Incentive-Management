<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "employee_notification_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$sender_name = $_POST['sender_name'];
$recipient_email = $_POST['recipient_email'];
$message = $_POST['message'];

// Insert notification into database
$sql = "INSERT INTO notifications (sender_name, recipient_email, message) 
        VALUES ('$sender_name', '$recipient_email', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "Notification sent successfully";
    header("Location: view_notifications.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>
