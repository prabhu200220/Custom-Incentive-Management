<?php
// Establish database connection
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP
$dbname = "registration";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["Email"];
    $password = $_POST["Password"];

    // Retrieve user from database based on email
    $sql = "SELECT * FROM users WHERE Email='$email' AND Password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == TRUE) {
        // Login successful
        session_start();
        header ("location : new2.php");
        exit();
        // You can redirect the user to another page here if needed
    } else {
        // Login failed
        echo "Invalid email or password.";
    }
}

$conn->close();
?>
