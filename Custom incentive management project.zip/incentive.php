<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "incentives_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sales = $_POST['sales'];
$target = $_POST['target'];
$incentive = $_POST['incentive'];
$bonus = $_POST['bonus'];
$holiday = isset($_POST['holiday']) ? 1 : 0;

$total_incentive = $sales * $incentive + $bonus;

$sql = "INSERT INTO incentives (sales, target, incentive, bonus, holiday, total_incentive)
        VALUES ($sales, $target, $incentive, $bonus, $holiday, $total_incentive)";

if ($conn->query($sql) === TRUE) {
    echo "Incentive calculated and saved successfully!";
    header("Location: view_incentives.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
